# traficFines

## Descripción
[Descripción breve del paquete]

## Instalación

### Desde el archivo .whl
```bash
pip install traficFines-0.1.0-py3-none-any.whl
```

### Desde el código fuente
```bash
pip install -e .
```

## Dependencias
[Lista de dependencias principales]

## Uso básico
[Ejemplos de uso básico]

## Estructura del paquete
[Descripción de la estructura]

## Autor
[Tu nombre] - [tu email]

## Licencia
[Licencia del proyecto]

